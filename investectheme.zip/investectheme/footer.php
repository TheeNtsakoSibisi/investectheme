<?php
    wp_footer();
?>
<p style="text-align: center;background-color:#6c6c6c">Copyright © Investec 2021</p>
</body>
</html>